export enum UserStatus {
    Active = 'active',
    Inactive = 'inactive',
    Suspened = 'suspended',
    Deleted = 'deleted'
  }